# Banking Application

## [Video Can Be Found Here](https://youtu.be/Xx7kKJqK4bQ)

### Participants

| Student Name   | Student ID Number |
| -------------- | ----------------- |
| Nariman Abrari | 1832561           |
| Wael Osman     | 1830059           |

<hr />

No clue if this is what you wanted. <br/>
I tried my best.
